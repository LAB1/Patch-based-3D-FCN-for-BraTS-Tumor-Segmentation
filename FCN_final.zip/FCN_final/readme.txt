core codes:

1. Patch_FCN_32.py
The network architecture and training.

2. Patch_Preprocessing_32.py
Read, preprocess the data and sample the patches.

3.Validation_32.py
Prediction and Bagging.

--------------------------------------
functional codes:

1. gif.py
Plot the segmentation results.

2. plot.py
Plot the evaluation results.

3.stacking_model.py
Stacking multiple models with SVM. (Too slow)
